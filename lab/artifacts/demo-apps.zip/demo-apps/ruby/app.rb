require 'sinatra'

get '/' do 
  "Hello from ruby!"
end


